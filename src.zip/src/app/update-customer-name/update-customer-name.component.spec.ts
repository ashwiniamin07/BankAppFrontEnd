import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateCustomerNameComponent } from './update-customer-name.component';

describe('UpdateCustomerNameComponent', () => {
  let component: UpdateCustomerNameComponent;
  let fixture: ComponentFixture<UpdateCustomerNameComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdateCustomerNameComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UpdateCustomerNameComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
