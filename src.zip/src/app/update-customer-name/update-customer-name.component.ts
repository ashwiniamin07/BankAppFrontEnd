// import { Component } from '@angular/core';
// import { CustomerServiceService } from '../services/customer-service.service';
// import { Router } from '@angular/router';

// @Component({
//   selector: 'app-update-customer-name',
//   templateUrl: './update-customer-name.component.html',
//   styleUrls: ['./update-customer-name.component.css']
// })
// export class UpdateCustomerNameComponent {
//   customerId: number | undefined;
//   currentName: string = '';
//   newName: string = '';
//   errorMessage: string = '';
//   successMessage: string = '';

//   constructor(private customerService: CustomerServiceService, private router: Router) {}

//   // Fetch the current name when the customer ID is provided
//   getCustomerName(): void {
//     if (!this.customerId) {
//       this.errorMessage = 'Please enter a valid Customer ID';
//       return;
//     }

//     // Call the API to fetch customer name by ID
//     // Here you can implement a getCustomerById() method in your service if necessary
//     // But for simplicity, we're assuming the customer already has a name field
//   }

//   // Update the customer name
//   updateCustomerName(): void {
//     if (!this.newName.trim()) {
//       this.errorMessage = 'New name cannot be empty';
//       return;
//     }
    
//     if (this.newName.length < 2) {
//       this.errorMessage = 'Name must be at least 2 characters long';
//       return;
//     }

//     this.customerService.updateCustomerName(this.customerId!, this.newName).subscribe(
//       (response) => {
//         this.successMessage = 'Customer name updated successfully!';
//         this.errorMessage = '';
//       },
//       (error) => {
//         this.errorMessage = error.error.message || 'An error occurred. Please try again later';
//         this.successMessage = '';
//       }
//     );
//   }
// }


import { Component } from '@angular/core';
import { CustomerServiceService } from '../services/customer-service.service';
import { Customer } from '../interface.models/customer';

@Component({
  selector: 'app-update-customer-name',
  templateUrl: './update-customer-name.component.html',
  styleUrls: ['./update-customer-name.component.css']
})
export class UpdateCustomerNameComponent {
  customerId!: number;
  currentName: string = '';
  newName: string = '';
  errorMessage: string = '';
  successMessage: string = '';

  constructor(private customerService: CustomerServiceService) {}

  getCustomerName(): void {
    if (!this.customerId || this.customerId <= 0) {
      this.errorMessage = 'Please enter a valid Customer ID.';
      return;
    }

    this.customerService.getCustomerById(this.customerId).subscribe(
      (customer: Customer) => {
        this.currentName = customer.fullName;
        this.newName = customer.fullName; // <-- Pre-fill newName input
        this.errorMessage = '';
      },
      (error) => {
        this.errorMessage = error.error.message || 'Customer not found';
        this.successMessage = '';
        this.currentName = '';
        this.newName = '';
      }
    );
  }

  updateCustomerName(): void {
    if (!this.newName.trim()) {
      this.errorMessage = 'New name cannot be empty';
      return;
    }

    if (this.newName.length < 2) {
      this.errorMessage = 'Name must be at least 2 characters long';
      return;
    }

    this.customerService.updateCustomerName(this.customerId, this.newName).subscribe(
      (response: Customer) => {
        this.successMessage = `Customer name updated to: ${response.fullName}`;
        this.errorMessage = '';
        this.currentName = response.fullName;
      },
      (error) => {
        this.errorMessage = error.error.message || 'Error updating name';
        this.successMessage = '';
      }
    );
  }
}
