import { Component, OnInit } from '@angular/core';
import { CustomerServiceService } from '../services/customer-service.service';
import { Customer } from '../interface.models/customer';

@Component({
  selector: 'app-get-customer-bydob',
  templateUrl: './get-customer-bydob.component.html',
  styleUrls: ['./get-customer-bydob.component.css']
})
export class GetCustomerBydobComponent implements OnInit {
  customers: Customer[] = [];
  searchedCustomers: Customer[] = [];
  error: string | null = null;
  searchDob: string = ''; // For customer DOB search

  constructor(private customerService: CustomerServiceService) {}

  ngOnInit(): void {
    this.fetchAllCustomers(); // Fetch all customers initially
  }

  // Method to fetch all customers
  fetchAllCustomers(): void {
    this.customerService.getAllCustomers().subscribe(
      (customers) => {
        this.customers = customers;
        this.error = null;
      },
      (error) => {
        this.error = 'Error fetching customers!';
      }
    );
  }

  // Method to search customers by DOB
  searchCustomerByDob(): void {
    if (!this.searchDob.trim()) {
      this.error = 'Please enter a valid customer DOB';
      this.searchedCustomers = [];
      return;
    }

    this.customerService.getCustomersByDob(this.searchDob).subscribe(
      (customers) => {
        this.searchedCustomers = customers;
        this.error = null;
      },
      (error) => {
        this.searchedCustomers = [];
        this.error = error.error.message || 'No customers found with the given DOB';
      }
    );
  }
}
