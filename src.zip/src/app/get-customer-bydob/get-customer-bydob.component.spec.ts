import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GetCustomerBydobComponent } from './get-customer-bydob.component';

describe('GetCustomerBydobComponent', () => {
  let component: GetCustomerBydobComponent;
  let fixture: ComponentFixture<GetCustomerBydobComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GetCustomerBydobComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GetCustomerBydobComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
