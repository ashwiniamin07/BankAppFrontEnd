import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { CustomerServiceService } from '../services/customer-service.service';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {

  constructor(private customerService: CustomerServiceService, private router: Router) {}

canActivate(
  next: ActivatedRouteSnapshot,
  state: RouterStateSnapshot): boolean {
  
  const currentCustomer = localStorage.getItem('customer');

  if (currentCustomer) {
    return true;  // user is logged in
  } else {
    this.router.navigate(['/home']);  // redirect to home or login
    return false;
  }
}
}
