import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { CustomerServiceService } from '../services/customer-service.service';

@Injectable({
  providedIn: 'root'
})
export class RoleGuard implements CanActivate {

  constructor(private customerService: CustomerServiceService, private router: Router) {}

  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {

    const requiredRole = next.data['role'];  // The role required to access this route
    const userRole = this.customerService.getCustomerRole();  // Get role from customer login object

    if (userRole === requiredRole) {
      return true;  // Allow access if the user has the correct role
    } else {
      // Redirect to an access-denied page or a suitable page
      this.router.navigate(['/access-denied']);
      return false;
    }
  }
}
