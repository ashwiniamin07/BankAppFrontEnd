


import { Component, OnInit } from '@angular/core';
import { CustomerServiceService } from '../services/customer-service.service';
import { Customer } from '../interface.models/customer';

@Component({
  selector: 'app-view-customers',
  templateUrl: './view-customers.component.html',
  styleUrls: ['./view-customers.component.css']
})
export class ViewCustomersComponent implements OnInit {
  customers: Customer[] = [];
  error: string | null = null;
  searchId: number | null = null; // For customer ID search
  searchedCustomer: Customer | null = null; // Single customer result

  constructor(private customerService: CustomerServiceService) {}

  ngOnInit(): void {
    this.fetchAllCustomers();
  }

  // Method to fetch all customers initially
  fetchAllCustomers(): void {
    this.customerService.getAllCustomers().subscribe(
      (customers) => {
        this.customers = customers;
        this.error = null;
      },
      (error) => {
        this.error = 'Error fetching customers!';
      }
    );
  }

  // Method to search a customer by ID
  searchCustomerById(): void {
    if (!this.searchId || this.searchId <= 0) {
      this.error = 'Please enter a valid customer ID';
      this.searchedCustomer = null;
      return;
    }

    this.customerService.getCustomerById(this.searchId).subscribe(
      (customer) => {
        this.searchedCustomer = customer;
        this.error = null;
      },
      (error) => {
        this.searchedCustomer = null;
        this.error = error.error.message || 'Customer not found!';
      }
    );
  }
}
