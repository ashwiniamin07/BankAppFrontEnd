import { Component } from '@angular/core';
import { CustomerServiceService } from '../services/customer-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-delete-customer',
  templateUrl: './delete-customer.component.html',
  styleUrls: ['./delete-customer.component.css']
})
export class DeleteCustomerComponent {
  customerId: number | undefined;
  errorMessage: string = ''; // To display error message

  constructor(
    private customerService: CustomerServiceService,
    private router: Router
  ) {}

  deleteCustomer(): void {
    if (!this.customerId) {
      this.errorMessage = 'Please enter a valid Customer ID';
      return;
    }

    this.customerService.deleteCustomer(this.customerId).subscribe(
      (response) => {
        // Assuming successful deletion redirects to a customer list
        console.log('Customer deleted successfully:', response);
        this.router.navigate(['/customers']);
      },
      (error) => {
        // Check for the 404 error code
        if (error.status === 404) {
          this.errorMessage = 'Customer ID ' + this.customerId + ' doesn\'t exist.';
        } else {
          this.errorMessage = 'An error occurred while deleting the customer. Please try again later.';
        }
      }
    );
  }
}
