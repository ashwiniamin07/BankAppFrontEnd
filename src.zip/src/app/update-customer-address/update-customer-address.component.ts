import { Component } from '@angular/core';
import { CustomerServiceService } from '../services/customer-service.service';
import { Customer } from '../interface.models/customer';
import { Address } from '../interface.models/address';

@Component({
  selector: 'app-update-customer-address',
  templateUrl: './update-customer-address.component.html',
  styleUrls: ['./update-customer-address.component.css']
})
export class UpdateCustomerAddressComponent {
  customerId!: number;
  address: Address = {
    dNo: '',
    streetName: '',
    city: '',
    state: '',
    pincode: 0
  };

  errorMessage = '';
  successMessage = '';
  addressLoaded = false;

  constructor(private customerService: CustomerServiceService) {}

  fetchCustomerAddress(): void {
    if (!this.customerId || this.customerId <= 0) {
      this.errorMessage = 'Enter a valid customer ID';
      return;
    }

    this.customerService.getCustomerById(this.customerId).subscribe(
      (customer: Customer) => {
        if (customer.address && customer.address.length > 0) {
          this.address = { ...customer.address[0] };
          this.addressLoaded = true;
          this.successMessage = '';
          this.errorMessage = '';
        } else {
          this.errorMessage = 'No address found for this customer';
          this.addressLoaded = false;
        }
      },
      (error) => {
        this.errorMessage = error.error.message || 'Customer not found';
        this.addressLoaded = false;
      }
    );
  }

  updateAddress(): void {
    if (!this.addressLoaded) {
      this.errorMessage = 'Fetch address before updating';
      return;
    }

    this.customerService.updateCustomerAddress(this.customerId, this.address).subscribe(
      (updatedCustomer: Customer) => {
        this.successMessage = 'Address updated successfully';
        this.errorMessage = '';
      },
      (error) => {
        this.errorMessage = error.error.message || 'Error updating address';
        this.successMessage = '';
      }
    );
  }
}
