import { Login } from './login';
import { Address } from './address';

export interface Customer {
  customerId: number;
  fullName: string;
  contactNo: string;
  dob: string; 
  login?: Login;
  address?: Address[];
}
