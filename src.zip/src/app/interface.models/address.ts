import { Customer } from './customer';

export interface Address {
  addressId?: number;
  dNo: string;
  streetName: string;
  city: string;
  state: string;
  pincode: number;
  customer?: Customer;
}

