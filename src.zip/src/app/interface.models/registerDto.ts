import { Customer } from './customer';
import { Address } from './address';
import { Login } from './login';

export interface RegisterDto {
  customer: Customer;
  login: Login;
  addressList: Address[];
}

