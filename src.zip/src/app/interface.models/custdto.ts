

export interface Custdto {
  customerId: number;
  fullName: string;
  contactNo: string;
  dob: string; 
  email: string;
}
