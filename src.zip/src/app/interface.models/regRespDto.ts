export interface RegRespDto {
    message: string;
    customerId: number;
  }
  