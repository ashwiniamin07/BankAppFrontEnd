// src/app/models/loginDto.ts
export interface LoginDto {
    email: string;
    password: string;
    role: string;
  }
  
