import { Customer } from './customer';

export interface Login {
  loginId?: number;
  email: string;
  password: string;
  role: string;
  customer?: Customer;
}
