import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GetCustomerBynameComponent } from './get-customer-byname.component';

describe('GetCustomerBynameComponent', () => {
  let component: GetCustomerBynameComponent;
  let fixture: ComponentFixture<GetCustomerBynameComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GetCustomerBynameComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GetCustomerBynameComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
