import { Component, OnInit } from '@angular/core';
import { CustomerServiceService } from '../services/customer-service.service';
import { Customer } from '../interface.models/customer';

@Component({
  selector: 'app-get-customer-byname',
  templateUrl: './get-customer-byname.component.html',
  styleUrls: ['./get-customer-byname.component.css']
})
export class GetCustomerBynameComponent implements OnInit {
  customers: Customer[] = [];
  searchedCustomers: Customer[] = []; // To store the search result
  error: string | null = null;
  searchName: string = ''; // For customer name search

  constructor(private customerService: CustomerServiceService) {}

  ngOnInit(): void {
    this.fetchAllCustomers(); // Fetch all customers initially
  }

  // Method to fetch all customers initially
  fetchAllCustomers(): void {
    this.customerService.getAllCustomers().subscribe(
      (customers) => {
        this.customers = customers;
        this.error = null;
      },
      (error) => {
        this.error = 'Error fetching customers!';
      }
    );
  }

  // Method to search customers by name
  searchCustomerByName(): void {
    if (!this.searchName.trim()) {
      this.error = 'Please enter a valid customer name';
      this.searchedCustomers = [];
      return;
    }

    this.customerService.getCustomersByName(this.searchName).subscribe(
      (customers) => {
        this.searchedCustomers = customers;
        this.error = null;
      },
      (error) => {
        this.searchedCustomers = [];
        this.error = error.error.message || 'No customers found with the given name';
      }
    );
  }
}
