import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TransactionPortalComponent } from './component/transaction-portal/transaction-portal.component';
import { DepositComponent } from './component/transaction-portal/deposit/deposit.component';
import { WithdrawComponent } from './component/transaction-portal/withdraw/withdraw.component';
import { TransferComponent } from './component/transaction-portal/transfer/transfer.component';
import { AccountComponent } from './component/account/account.component';
import { LoginComponent } from './component/login/login.component';
import { ProfileComponent } from './component/profile/profile.component';
import { AccountCreateComponent } from './component/account/account-create/account-create.component';
import { AccountDetailComponent } from './component/account/account-detail/account-detail.component';
import { AccountBalanceComponent } from './component/account/account-balance/account-balance.component';
import { AccountCustomerDetailsComponent } from './component/account/account-customer-details/account-customer-details.component';
import { AccountDeleteComponent } from './component/account/account-delete/account-delete.component';
import { AccountFreezeComponent } from './component/account/account-freeze/account-freeze.component';
import { AccountListComponent } from './component/account/account-list/account-list.component';
import { AccountUpdateComponent } from './component/account/account-update/account-update.component';
import { AccountVerifyComponent } from './component/account/account-verify/account-verify.component';
import { TransactionStatementComponent } from './component/account/transaction-statement/transaction-statement.component';
import { AccountByCustomerComponent } from './component/account/account-by-customer/account-by-customer.component';
import { AboutComponent } from './component/about/about.component';
import { RegisterComponent } from './component/register/register.component';
import { HomeComponent } from './component/home/home.component';
import { CustomerComponent } from './component/customer/customer.component';
import { AccessDeniedComponent } from './access-denied/access-denied.component';
import { UpdateCustomerComponent } from './update-customer/update-customer.component';
import { DeleteCustomerComponent } from './delete-customer/delete-customer.component';
import { GetCustomerBydobComponent } from './get-customer-bydob/get-customer-bydob.component';
import { GetCustomerByemailComponent } from './get-customer-byemail/get-customer-byemail.component';
import { GetCustomerBynameComponent } from './get-customer-byname/get-customer-byname.component';
import { GetCustomerDtoComponent } from './get-customer-dto/get-customer-dto.component';
import { UpdateCustomerAddressComponent } from './update-customer-address/update-customer-address.component';
import { UpdateCustomerDobComponent } from './update-customer-dob/update-customer-dob.component';
import { UpdateCustomerDtoComponent } from './update-customer-dto/update-customer-dto.component';
import { UpdateCustomerNameComponent } from './update-customer-name/update-customer-name.component';
import { AuthGuard } from './guards/auth.guard';
import { RoleGuard } from './guards/role.guard';




const routes: Routes = [
  {path: 'profile', component: ProfileComponent,canActivate: [AuthGuard]},
  {path: 'customer', component: CustomerComponent, canActivate: [AuthGuard]},
  { path: 'about', component:AboutComponent},
  { path: 'register', component:RegisterComponent},
  { path: 'login',component:LoginComponent },
  { path: 'accounts',component:AccountComponent,canActivate: [AuthGuard]},
  { path: 'transaction', component:TransactionPortalComponent,canActivate: [AuthGuard]},
  { path: '', component:HomeComponent},

  { path: 'transaction/deposit', component:DepositComponent,canActivate: [AuthGuard]},
  { path: 'transaction/withdraw', component:WithdrawComponent,canActivate: [AuthGuard]  },
  { path: 'transaction/transfer', component:TransferComponent,canActivate: [AuthGuard] },

  { path: 'accounts/create', component:AccountCreateComponent,canActivate: [AuthGuard]},
  { path: 'accounts/details', component:AccountDetailComponent,canActivate: [AuthGuard]},
  { path: 'accounts/balance',component:AccountBalanceComponent,canActivate: [AuthGuard]},
  { path: 'accounts/getcustdetails',component:AccountCustomerDetailsComponent,canActivate: [AuthGuard]},
  { path: 'accounts/delete',component:AccountDeleteComponent,canActivate: [AuthGuard]},
  { path: 'accounts/freeze',component:AccountFreezeComponent,canActivate: [AuthGuard]},
  { path: 'accounts/list',component:AccountListComponent,canActivate: [AuthGuard]},
  { path: 'accounts/update',component:AccountUpdateComponent,canActivate: [AuthGuard]},
  { path: 'accounts/verify',component:AccountVerifyComponent,canActivate: [AuthGuard]},
  { path: 'accounts/cust',component:AccountByCustomerComponent,canActivate: [AuthGuard]},
  { path: 'accounts/statement',component:TransactionStatementComponent,canActivate: [AuthGuard]},


  {
    path: 'admin',
    component: CustomerComponent,  // Adjust to your actual admin component
    canActivate: [AuthGuard, RoleGuard],
    data: { role: 'ADMIN' }  // Only allow users with 'ADMIN' role
  },
  { path: 'access-denied', component: AccessDeniedComponent },  // Access Denied Page
  { path: '**', redirectTo: '' },  // Wildcard for unknown routes
  
  {path: 'update/:id', component: UpdateCustomerComponent,canActivate: [AuthGuard]},
  { path: 'delete-customer', component: DeleteCustomerComponent,canActivate: [AuthGuard]},
  { path: 'update-name', component: UpdateCustomerNameComponent,canActivate: [AuthGuard]}, 
  { path: 'update-address', component: UpdateCustomerAddressComponent,canActivate: [AuthGuard]}, 
  { path: 'update-dob', component: UpdateCustomerDobComponent,canActivate: [AuthGuard]},
  { path: 'get-byname', component: GetCustomerBynameComponent,canActivate: [AuthGuard]},
  { path: 'get-bydob', component: GetCustomerBydobComponent,canActivate: [AuthGuard]},
  { path: 'get-byemail', component: GetCustomerByemailComponent,canActivate: [AuthGuard]},
  { path: 'get-dto', component: GetCustomerDtoComponent,canActivate: [AuthGuard]},
  { path: 'update-dto', component: UpdateCustomerDtoComponent,canActivate: [AuthGuard]},

  

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
