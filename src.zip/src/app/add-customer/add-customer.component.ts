import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormArray } from '@angular/forms';
import { CustomerServiceService } from '../services/customer-service.service';
import { Customer } from '../interface.models/customer';

@Component({
  selector: 'app-add-customer',
  templateUrl: './add-customer.component.html'
})
export class AddCustomerComponent implements OnInit {
  addCustomerForm: FormGroup;
  successMessage: string = '';
  errorMessage: string = '';

  constructor(private fb: FormBuilder, private customerService: CustomerServiceService) {
    // Form Group definition with all customer-related fields
    this.addCustomerForm = this.fb.group({
      fullName: ['', [Validators.required, Validators.minLength(2)]],
      contactNo: ['', [Validators.required, Validators.pattern('^[6-9]\\d{9}$')]], // Mobile number pattern
      dob: ['', Validators.required],  // Date of birth should be required
      login: this.fb.group({
        email: ['', [Validators.required, Validators.email]], // Email should be valid
        password: ['', [Validators.required, Validators.minLength(8)]],  // Password should be at least 8 characters
        role: ['USER', Validators.required]  // Default role is 'USER'
      }),
      addressList: this.fb.array([this.createAddressGroup()]) // Address list with one address field initially
    });
  }

  ngOnInit(): void {}

  // Getters for easy access to nested form controls
  get addressList(): FormArray {
    return this.addCustomerForm.get('addressList') as FormArray;
  }

  // Create address form group
  createAddressGroup(): FormGroup {
    return this.fb.group({
      dNo: ['', Validators.required],
      streetName: ['', Validators.required],
      city: ['', Validators.required],
      state: ['', Validators.required],
      pincode: ['', [Validators.required, Validators.min(100000), Validators.max(999999)]], // Pincode should be 6 digits
    });
  }

  // Add a new address form group
  addAddress(): void {
    this.addressList.push(this.createAddressGroup());
  }

  // Submit the form to backend service
  onSubmit(): void {
    if (this.addCustomerForm.invalid) {
      this.errorMessage = 'Please fill out all required fields correctly.';
      return;
    }

    const dob = this.addCustomerForm.get('dob')?.value;
    if (dob) {
      const today = new Date();
      const dobDate = new Date(dob);
      if (dobDate > today) {
        this.errorMessage = 'Date of birth must be a past date.';
        return;
      }
    }

    const customerData: Customer = {
      ...this.addCustomerForm.value,
      address: this.addCustomerForm.value.addressList,  // Correct mapping
      addressList: undefined                            // Remove addressList if needed
    };
    
    console.log('Form Data:', customerData);  // Log the form data for debugging

    this.customerService.addCustomer(customerData).subscribe({
      next: (response) => {
        this.successMessage = 'Customer added successfully!';
        this.errorMessage = '';
        this.addCustomerForm.reset();
      },
      error: (err) => {
        console.log('Error response:', err);  // Log the error for debugging
        if (err.status === 400 && err.error && err.error.includes('Email already exists')) {
          this.errorMessage = 'Customer with this email already exists. Please try with a different email id.';
        } else {
          this.errorMessage = 'Failed to add customer. Please try again.';
        }
        this.successMessage = '';
      }
    });
  }
}
