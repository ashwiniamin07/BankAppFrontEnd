import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule} from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TransactionPortalComponent } from './component/transaction-portal/transaction-portal.component';
import { TransferComponent } from './component/transaction-portal/transfer/transfer.component';
import { DepositComponent } from './component/transaction-portal/deposit/deposit.component';
import { WithdrawComponent } from './component/transaction-portal/withdraw/withdraw.component';
import { LoginComponent } from './component/login/login.component';
import { ProfileComponent } from './component/profile/profile.component';
import { AccountComponent } from './component/account/account.component';
import { AccountCreateComponent } from './component/account/account-create/account-create.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { AccountDetailComponent } from './component/account/account-detail/account-detail.component'
import { AccountBalanceComponent } from './component/account/account-balance/account-balance.component';
import { AccountCustomerDetailsComponent } from './component/account/account-customer-details/account-customer-details.component';
import { AccountDeleteComponent } from './component/account/account-delete/account-delete.component';
import { AccountFreezeComponent } from './component/account/account-freeze/account-freeze.component';
import { AccountListComponent } from './component/account/account-list/account-list.component';
import { AccountUpdateComponent } from './component/account/account-update/account-update.component';
import { AccountVerifyComponent } from './component/account/account-verify/account-verify.component';
import { AccountByCustomerComponent } from './component/account/account-by-customer/account-by-customer.component';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { TransactionStatementComponent } from './component/account/transaction-statement/transaction-statement.component';
import { MatTabsModule } from '@angular/material/tabs';
import { MatToolbarModule } from '@angular/material/toolbar';
import { HomeComponent } from './component/home/home.component';
import { AboutComponent } from './component/about/about.component';
import { RegisterComponent } from './component/register/register.component';
import { CustomerComponent } from './component/customer/customer.component'; 
import { AddCustomerComponent } from './add-customer/add-customer.component';
import { ViewCustomersComponent } from './view-customers/view-customers.component';
import { DeleteCustomerComponent } from './delete-customer/delete-customer.component';
import { UpdateCustomerComponent } from './update-customer/update-customer.component';
import { UpdateCustomerNameComponent } from './update-customer-name/update-customer-name.component';
import { UpdateCustomerAddressComponent } from './update-customer-address/update-customer-address.component';
import { UpdateCustomerDobComponent } from './update-customer-dob/update-customer-dob.component';
import { GetCustomerBynameComponent } from './get-customer-byname/get-customer-byname.component';
import { GetCustomerByemailComponent } from './get-customer-byemail/get-customer-byemail.component';
import { GetCustomerDtoComponent } from './get-customer-dto/get-customer-dto.component';
import { GetCustomerBydobComponent } from './get-customer-bydob/get-customer-bydob.component';
import { AccessDeniedComponent } from './access-denied/access-denied.component';
import { UpdateCustomerDtoComponent } from './update-customer-dto/update-customer-dto.component';
import { RouterModule } from '@angular/router';

@NgModule({
  declarations: [
    AppComponent,
    TransactionPortalComponent,
    DepositComponent,
    WithdrawComponent,
    TransferComponent,
    LoginComponent,
    ProfileComponent,
    AccountComponent,
    AccountCreateComponent,
    AccountDetailComponent,
    AccountBalanceComponent,
    AccountCustomerDetailsComponent,
    AccountDeleteComponent,
    AccountFreezeComponent,
    AccountListComponent,
    AccountUpdateComponent,
    AccountVerifyComponent,
    AccountByCustomerComponent,
    AccountByCustomerComponent,
    TransactionStatementComponent,
    HomeComponent,
    AboutComponent,
    RegisterComponent,
    CustomerComponent,
    ViewCustomersComponent,
    AddCustomerComponent,
    UpdateCustomerComponent,
    DeleteCustomerComponent,
    UpdateCustomerNameComponent,
    UpdateCustomerAddressComponent,
    UpdateCustomerDobComponent,
    GetCustomerBynameComponent,
    GetCustomerBydobComponent,
    GetCustomerByemailComponent,
    GetCustomerDtoComponent,
    UpdateCustomerDtoComponent,
    AccessDeniedComponent

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatTableModule,
    MatCardModule,
    MatTabsModule,
    MatToolbarModule,
    RouterModule.forRoot([ // Define routes if not already done
      { path: 'register', component: RegisterComponent },  // Example route
      { path: 'about', component: AboutComponent },
      { path: 'account', component:AccountComponent},
      { path: 'transaction', component:TransactionPortalComponent}
      // Your other routes here
    ])

  ],
  
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
