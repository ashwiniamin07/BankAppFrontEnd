import { Component } from '@angular/core';

@Component({
  selector: 'app-access-denied',
  template: `
    <div class="container">
      <h1>Access Denied</h1>
      <p>You do not have permission to view this page.</p>
      <a routerLink="/">Go to Home</a>
    </div>
  `,
  styleUrls: ['./access-denied.component.css']
})
export class AccessDeniedComponent {}
