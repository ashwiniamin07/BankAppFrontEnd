import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GetCustomerDtoComponent } from './get-customer-dto.component';

describe('GetCustomerDtoComponent', () => {
  let component: GetCustomerDtoComponent;
  let fixture: ComponentFixture<GetCustomerDtoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GetCustomerDtoComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GetCustomerDtoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
