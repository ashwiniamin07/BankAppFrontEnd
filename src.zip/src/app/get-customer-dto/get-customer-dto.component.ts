import { Component } from '@angular/core';
import { CustomerServiceService } from '../services/customer-service.service';
import { Custdto } from '../interface.models/custdto';

@Component({
  selector: 'app-get-customer-dto',
  templateUrl: './get-customer-dto.component.html',
  styleUrls: ['./get-customer-dto.component.css']
})
export class GetCustomerDtoComponent {
  customerId: number | null = null;
  custDto: Custdto | null = null;
  error: string | null = null;

  constructor(private customerService: CustomerServiceService) {}

  searchCustomerDto(): void {
    if (this.customerId == null) {
      this.error = 'Please enter a valid Customer ID';
      this.custDto = null;
      return;
    }

    this.customerService.getCustomerDtoById(this.customerId).subscribe(
      (response) => {
        this.custDto = response;
        this.error = null;
      },
      (error) => {
        this.custDto = null;
        this.error = error.error.message || 'Customer DTO not found';
      }
    );
  }
}

