import { Component } from '@angular/core';
import { CustomerServiceService } from '../services/customer-service.service';
import { Custdto } from '../interface.models/custdto';

@Component({
  selector: 'app-update-customer-dto',
  templateUrl: './update-customer-dto.component.html',
  styleUrls: ['./update-customer-dto.component.css']
})
export class UpdateCustomerDtoComponent {
  searchId: number | null = null;
  custDto: Custdto | null = null;
  successMessage: string | null = null;
  error: string | null = null;

  constructor(private customerService: CustomerServiceService) {}

  // Step 1: Fetch customer by ID
  fetchCustomer(): void {
    this.successMessage = null;
    this.error = null;

    if (this.searchId == null) {
      this.error = 'Please enter a valid Customer ID';
      return;
    }

    this.customerService.getCustomerDtoById(this.searchId).subscribe(
      (response) => {
        this.custDto = response;
        this.error = null;
      },
      (error) => {
        this.custDto = null;
        this.error = error.error.message || 'Customer not found';
      }
    );
  }

  // Step 2: Update the customer
  updateCustomer(): void {
    if (!this.custDto) return;

    this.customerService.updateCustomerDto(this.custDto.customerId, this.custDto).subscribe(
      (response) => {
        this.custDto = response;
        this.successMessage = 'Customer updated successfully!';
        this.error = null;
      },
      (error) => {
        this.successMessage = null;
        this.error = error.error.message || 'Error updating customer';
      }
    );
  }
}
