import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateCustomerDtoComponent } from './update-customer-dto.component';

describe('UpdateCustomerDtoComponent', () => {
  let component: UpdateCustomerDtoComponent;
  let fixture: ComponentFixture<UpdateCustomerDtoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdateCustomerDtoComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UpdateCustomerDtoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
