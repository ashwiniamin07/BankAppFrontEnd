import { Component, OnInit } from '@angular/core';
import { CustomerServiceService } from '../services/customer-service.service';
import { Customer } from '../interface.models/customer';

@Component({
  selector: 'app-get-customer-byemail',
  templateUrl: './get-customer-byemail.component.html',
  styleUrls: ['./get-customer-byemail.component.css']
})
export class GetCustomerByemailComponent implements OnInit {
  email: string = '';
  customer: Customer | null = null;
  error: string | null = null;

  constructor(private customerService: CustomerServiceService) {}

  ngOnInit(): void {}

  searchCustomerByEmail(): void {
    if (!this.email.trim()) {
      this.error = 'Please enter a valid email address';
      this.customer = null;
      return;
    }

    this.customerService.getCustomerByEmail(this.email).subscribe(
      (customer) => {
        this.customer = customer;
        this.error = null;
      },
      (error) => {
        this.customer = null;
        this.error = error.error.message || 'No customer found with the given email';
      }
    );
  }
}
