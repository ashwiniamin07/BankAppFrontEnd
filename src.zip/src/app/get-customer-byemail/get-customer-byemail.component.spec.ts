import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GetCustomerByemailComponent } from './get-customer-byemail.component';

describe('GetCustomerByemailComponent', () => {
  let component: GetCustomerByemailComponent;
  let fixture: ComponentFixture<GetCustomerByemailComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GetCustomerByemailComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GetCustomerByemailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
