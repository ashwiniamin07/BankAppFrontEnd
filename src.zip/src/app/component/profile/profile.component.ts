import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CustomerServiceService } from '../../services/customer-service.service';
import { Customer } from '../../interface.models/customer';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  user: Customer | null = null;

  constructor(private customerService: CustomerServiceService, private router: Router) {}

  ngOnInit(): void {
    // Fetch the user details when the component is initialized
    this.customerService.getCustomer().subscribe((customer) => {
      if (customer) {
        this.user = customer;  // Store the customer data if available
      } else {
        // If no user is found, navigate back to login
        this.router.navigate(['/login']);
      }
    });
  }

  // Handle logout (if required on the profile page)
  logout(): void {
    this.customerService.logout();
    this.router.navigate(['/login']);  // Redirect to login page after logout
  }
  goHome(): void {
    this.router.navigate(['']);  // Navigate to home page
  }
}


