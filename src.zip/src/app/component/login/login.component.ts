


import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CustomerServiceService } from '../../services/customer-service.service'; // Import your service
import { LoginDto } from '../../interface.models/loginDto';  // Assuming LoginDto interface
import { Customer } from '../../interface.models/customer'; // Import the Customer interface

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginData: LoginDto = {
    email: '',
    password: '',
    role: '' // Add a role field as per your backend
  };

  isLoggedIn: boolean = false;
  user: Customer | null = null;
  loginError: string | null = null;

  constructor(private customerService: CustomerServiceService, private router: Router) {}

  ngOnInit(): void {
    // Check if the user is already logged in
    this.customerService.getCustomer().subscribe((customer) => {
      if (customer) {
        this.isLoggedIn = true;
        this.user = customer;
      } else {
        this.isLoggedIn = false;
        this.user = null;
      }
    });
  }

  // Handle login form submission
  onLoginSubmit() {
    console.log('Submitting login data:', this.loginData);  // Add console log to check what is sent to backend
    this.customerService.loginCustomer(this.loginData).subscribe(
      (customer) => {
        // On successful login, store the customer data and navigate to the home page
        this.customerService.setCustomer(customer);
        console.log('Login successful, customer:', customer);  // Log the customer data
        this.router.navigate(['/home']); // Redirect to home page
        this
      },
      (error) => {
        // On login failure, show error message
        console.log('Login failed, error:', error);  // Log the error for debugging
        this.loginError = 'Invalid credentials, please try again!';
      }
    );
  }

  // Handle logout
  logout() {
    this.customerService.logout();
    this.router.navigate(['/login']); // Redirect to login page after logout
  }
}




