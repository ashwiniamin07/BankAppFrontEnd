import { Component } from '@angular/core';
import { AccountService } from 'src/app/services/account.service';

@Component({
  selector: 'app-account-freeze',
  templateUrl: './account-freeze.component.html',
  styleUrls: ['./account-freeze.component.css']
})
export class AccountFreezeComponent {
  accountId: number = 0;  // Account ID input
  message: string = '';    // Message to show the result
  isLoading: boolean = false; // To handle the loading state
  showMessage: boolean = false; // To show the success/error message

  constructor(private accountService: AccountService) {}

  ngOnInit(): void {}

  onFreeze(): void {
    this.isLoading = true;
    this.showMessage = false; // Hide any previous message

    if (this.accountId && this.accountId > 0) {
      // Call the freezeAccount method from AccountService
      this.accountService.freezeAccount(this.accountId).subscribe({
        next: (res: string) => {
          console.log('Freeze response:', res); // Log the response for debugging
          this.message = res; // Set the message to the response from backend
          this.showMessage = true; // Show the message
          this.isLoading = false; // Hide the loading state
        },
        error: (err) => {
          console.error('Error freezing account:', err);
          this.message = 'Failed to freeze the account. Please check the account number.';
          this.showMessage = true;
          this.isLoading = false;
        }
      });
    } else {
      this.message = 'Please enter a valid account number.';
      this.showMessage = true;
      this.isLoading = false;
    }
  }

  onUnfreeze(): void {
    this.isLoading = true;
    this.showMessage = false; // Hide any previous message

    if (this.accountId && this.accountId > 0) {
      // Call the unfreezeAccount method from AccountService
      this.accountService.unfreezeAccount(this.accountId).subscribe({
        next: (res: string) => {
          console.log('Unfreeze response:', res); // Log the response for debugging
          this.message = res; // Set the message to the response from backend
          this.showMessage = true; // Show the message
          this.isLoading = false; // Hide the loading state
        },
        error: (err) => {
          console.error('Error unfreezing account:', err);
          this.message = 'Failed to unfreeze the account. Please check the account number.';
          this.showMessage = true;
          this.isLoading = false;
        }
      });
    } else {
      this.message = 'Please enter a valid account number.';
      this.showMessage = true;
      this.isLoading = false;
    }
  }
}
