import { Component } from '@angular/core';
import { Account } from 'src/app/models/account.model';
import { AccountService } from 'src/app/services/account.service';

@Component({
  selector: 'app-account-balance',
  templateUrl: './account-balance.component.html',
  styleUrls: ['./account-balance.component.css']
})
export class AccountBalanceComponent {
  accountId: number | null = null;
  balance: number | null = null;
  hasChecked: boolean = false;
  hasError: boolean = false;
 role: string|null = null;
  customerId: number | null = null;
    accounts: Account[] = [];
  
    constructor(
      private accountService:AccountService, 
      ){}

      ngOnInit(): void {
        const customerData = localStorage.getItem('customer');
        if (customerData) {
          const customer = JSON.parse(customerData);
          this.role = customer.login?.role || null;
          this.customerId = customer.customerId;
    
          if (this.role === 'USER' && this.customerId) {
            this.accountService.getAccountsByCustomerId(this.customerId).subscribe(accounts => {
              this.accounts = accounts;
            });
          } else 
          if (this.role === 'ADMIN') {
            this.accountService.getAllAccounts().subscribe(accounts => {
              this.accounts = accounts;
            });
          }
        }
    
        window.addEventListener('storage', (event) => {
          if (event.key === 'customer' && event.newValue === null) {
            window.location.href = '/home';
          }
        });
        console.log('CustomerID:',this.customerId);
        console.log('Role',this.role)
      }


  getBalance(): void {
    this.hasChecked = true;
    this.hasError = false;
    this.balance = null;

    if (!this.accountId || this.accountId <= 0) {
      this.hasError = true;
      return;
    }

    this.accountService.getBalance(this.accountId).subscribe({
      next: (data) => {
        this.balance = data;
      },
      error: () => {
        this.hasError = true;
      }
    });
  }
}
