import { Component } from '@angular/core';
import { AccountService } from 'src/app/services/account.service';

@Component({
  selector: 'app-account-verify',
  templateUrl: './account-verify.component.html',
  styleUrls: ['./account-verify.component.css']
})
export class AccountVerifyComponent {
  accountId: number = 0;
  exists: boolean | null = null;
  hasSubmitted: boolean = false;

  constructor(private accountService: AccountService) {}

  verifyAccount(): void {
    if (!this.accountId || this.accountId <= 0) {
      this.exists = false;
      this.hasSubmitted = true;
      return;
    }

    this.hasSubmitted = true;
    this.exists = null; // show "Verifying..." message

    this.accountService.verifyAccountExists(this.accountId).subscribe({
      next: (result) => {
        this.exists = result;
      },
      error: (error) => {
        console.error('Error verifying account:', error);
        this.exists = false;
      }
    });
  }
}
