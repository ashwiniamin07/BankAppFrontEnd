import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AccountService } from 'src/app/services/account.service';  // Ensure to import your service
import { Router } from '@angular/router';

@Component({
  selector: 'app-account-create',
  templateUrl: './account-create.component.html',
  styleUrls: ['./account-create.component.css']
})
export class AccountCreateComponent implements OnInit {

  accountForm: FormGroup;
  accountTypes = [
    { value: 'Saving', display: 'Savings Account' },
    { value: 'Current', display: 'Current Account' },
    // { value: 'Salary', display: 'Salary Account' },
    // { value: 'FD', display: 'Fixed Deposit (FD) Account' },
    // { value: 'RD', display: 'Recurring Deposit (RD) Account' },
    // { value: 'NRI', display: 'NRI Account' }
  ];
  statusMessage: string = ''; // Variable to hold the success or error message
  statusClass: string = ''; // To dynamically set a class for success or error

  constructor(
    private fb: FormBuilder,
    private accountService: AccountService,
    private router: Router // Inject Router service
  ) {
    // Initialize the form using FormBuilder
    this.accountForm = this.fb.group({
      accountType: ['', Validators.required],  // Dropdown for selecting account type
      balance: ['', [Validators.required, Validators.min(1)]],  // Balance field
      customerId: ['', Validators.required]  // Customer ID field
    });
  }

  ngOnInit(): void {
    const customerData = localStorage.getItem('customer');
    if (customerData) {
      const customer = JSON.parse(customerData);
      const customerId = customer.customerId;
  
      if (customerId) {
        this.accountForm.patchValue({ customerId }); // auto-fill the field
        this.accountForm.get('customerId')?.disable(); // make it read-only
      }
    }
  }

  logout(){
    localStorage.clear();
    sessionStorage.clear();

    this.router.navigate(['/login']);
  }

  // Handle form submission
  onSubmit(): void {
    if (this.accountForm.valid) {
      const customerData = localStorage.getItem('customer');
      let customerId = null;
      if (customerData) {
        const customer = JSON.parse(customerData);
        customerId = customer.customerId;
      }
  
      const accountData = {
        ...this.accountForm.getRawValue(), // get disabled + enabled values
        customerId: customerId             // ensure customerId is included
      };
  
      this.accountService.createAccount(accountData).subscribe(
        (response) => {
          console.log('Account created successfully:', response);
          this.statusMessage = 'Account created successfully!';
          this.statusClass = 'success-message';
          this.accountForm.reset();

          setTimeout(() => {
            window.location.reload();
          },1000);
        },
        (error) => {
          console.error('Error creating account:', error);
          this.statusMessage = 'Error creating account. Please try again.';
          this.statusClass = 'error-message';
        }
      );
    }
  }
}
