import { Component ,OnInit} from '@angular/core';
import { AccountService } from 'src/app/services/account.service';
import { Account } from 'src/app/models/account.model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-account-list',
  templateUrl: './account-list.component.html',
  styleUrls: ['./account-list.component.css']
})
export class AccountListComponent implements OnInit {
  accounts: Account[] = [];

  constructor(private accountService: AccountService, private router: Router) {}

  ngOnInit(): void {
    this.getAllAccounts();
  }

  getAllAccounts(): void {
    this.accountService.getAllAccounts().subscribe((data: Account[]) => {
      this.accounts = data;
    });
  }

  goToDetail(accountId: number): void {
    this.router.navigate(['/account-detail', accountId]);
  }

  goToCreate(): void {
    this.router.navigate(['/account-create']);
  }


}
