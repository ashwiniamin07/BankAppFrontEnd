import { Component } from '@angular/core';
import { Account } from 'src/app/models/account.model';
import { AccountService } from 'src/app/services/account.service';


@Component({
  selector: 'app-account-by-customer',
  templateUrl: './account-by-customer.component.html',
  styleUrls: ['./account-by-customer.component.css']
})
export class AccountByCustomerComponent {
  customerId!: number;
  accounts: Account[] = [];
  errorMessage: string = '';  // To show error messages
  isLoading: boolean = false; // To show loading state

  constructor(private accountService: AccountService) {}

  // Method to fetch accounts by customer ID
  getAccountsByCustomer() {
    if (!this.customerId) {
      this.errorMessage = 'Please enter a valid customer ID.';
      return;
    }

    this.isLoading = true;
    this.accountService.getAccountsByCustomerId(this.customerId).subscribe(
      (accounts) => {
        this.isLoading = false;
        if (accounts && accounts.length > 0) {
          this.accounts = accounts;
          this.errorMessage = ''; // Reset error message if accounts found
        } else {
          this.errorMessage = 'No accounts found for this customer ID.';
          this.accounts = [];  // Clear the accounts list if none are found
        }
      },
      (error) => {
        this.isLoading = false;
        this.errorMessage = 'Error fetching accounts. Please try again.';
      }
    );
  }
}
