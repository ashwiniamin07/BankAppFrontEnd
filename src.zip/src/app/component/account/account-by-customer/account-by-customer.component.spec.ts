import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AccountByCustomerComponent } from './account-by-customer.component';

describe('AccountByCustomerComponent', () => {
  let component: AccountByCustomerComponent;
  let fixture: ComponentFixture<AccountByCustomerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AccountByCustomerComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AccountByCustomerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
