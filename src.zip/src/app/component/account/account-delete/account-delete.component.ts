import { Component } from '@angular/core';
import { Account } from 'src/app/models/account.model';
import { AccountService } from 'src/app/services/account.service';

@Component({
  selector: 'app-account-delete',
  templateUrl: './account-delete.component.html',
  styleUrls: ['./account-delete.component.css']
})
export class AccountDeleteComponent {
  enteredAccountId!: number;
  confirmDelete: boolean = false;

  constructor(private accountService: AccountService) {}

  role: string|null = null;
    customerId: number | null = null;
      accounts: Account[] = [];
  
        ngOnInit(): void {
          const customerData = localStorage.getItem('customer');
          if (customerData) {
            const customer = JSON.parse(customerData);
            this.role = customer.login?.role || null;
            this.customerId = customer.customerId;
      
            if (this.role === 'USER' && this.customerId) {
              this.accountService.getAccountsByCustomerId(this.customerId).subscribe(accounts => {
                this.accounts = accounts;
              });
            } else 
            if (this.role === 'ADMIN') {
              this.accountService.getAllAccounts().subscribe(accounts => {
                this.accounts = accounts;
              });
            }
          }
      
          window.addEventListener('storage', (event) => {
            if (event.key === 'customer' && event.newValue === null) {
              window.location.href = '/home';
            }
          });
          console.log('CustomerID:',this.customerId);
          console.log('Role',this.role)
        }

  showConfirmation() {
    if (this.enteredAccountId) {
      this.confirmDelete = true;
    } else {
      alert('Please enter an account number.');
    }
  }

  deleteAccount() {
    this.accountService.deleteAccount(this.enteredAccountId).subscribe(() => {
      alert(`Account ${this.enteredAccountId} deleted successfully!`);
      this.resetForm();
    }, error => {
      alert('Error deleting account');
    });
  }

  cancelConfirmation() {
    this.confirmDelete = false;
  }

  resetForm() {
    this.enteredAccountId = undefined!;
    this.confirmDelete = false;
  }
}
