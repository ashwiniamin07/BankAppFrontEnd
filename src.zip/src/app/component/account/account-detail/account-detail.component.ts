import { Component } from '@angular/core';
import { AccountService } from 'src/app/services/account.service';
import { Account } from 'src/app/models/account.model';

@Component({
  selector: 'app-account-detail',
  templateUrl: './account-detail.component.html',
  styleUrls: ['./account-detail.component.css']
})
export class AccountDetailComponent {
  accountNo: number | null = null;  // To store the account number entered by the user
  account: Account | null = null;  // To store the fetched account details
  isLoading: boolean = false;  // To show loading indicator
  errorMessage: string = '';   // To store any error messages

  constructor(private accountService: AccountService) {}

  role: string|null = null;
    customerId: number | null = null;
      accounts: Account[] = [];
  
        ngOnInit(): void {
          const customerData = localStorage.getItem('customer');
          if (customerData) {
            const customer = JSON.parse(customerData);
            this.role = customer.login?.role || null;
            this.customerId = customer.customerId;
      
            if (this.role === 'USER' && this.customerId) {
              this.accountService.getAccountsByCustomerId(this.customerId).subscribe(accounts => {
                this.accounts = accounts;
              });
            } else 
            if (this.role === 'ADMIN') {
              this.accountService.getAllAccounts().subscribe(accounts => {
                this.accounts = accounts;
              });
            }
          }
      
          window.addEventListener('storage', (event) => {
            if (event.key === 'customer' && event.newValue === null) {
              window.location.href = '/home';
            }
          });
          console.log('CustomerID:',this.customerId);
          console.log('Role',this.role)
        }

  // Function to fetch account details based on entered account number
  fetchAccountDetails(): void {
    if (!this.accountNo) {
      this.errorMessage = 'Please enter a valid account number';
      return;
    }

    this.isLoading = true;
    this.errorMessage = '';  // Clear any previous error

    // Call the service to fetch the account details
    this.accountService.getAccountById(this.accountNo).subscribe(
      (account) => {
        this.account = account;
        this.isLoading = false;  // Stop loading
      },
      (error) => {
        this.errorMessage = 'Failed to fetch account details. Please try again.';
        this.isLoading = false;  // Stop loading
        console.error(error);
      }
    );
  }
}
