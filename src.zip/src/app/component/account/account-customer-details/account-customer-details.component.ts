import { Component } from '@angular/core';
import { Customer } from 'src/app/models/customer.model';
import { AccountService } from 'src/app/services/account.service';
 
@Component({
  selector: 'app-account-customer-details',
  templateUrl: './account-customer-details.component.html',
  styleUrls: ['./account-customer-details.component.css']
})
export class AccountCustomerDetailsComponent {
  accountId!: number;
  customerDetails?: Customer;
  errorMessage: string = '';
  isLoading: boolean = false;
 
  constructor(private accountService: AccountService) {}
 
  // Function to fetch customer details based on entered accountId
  fetchCustomerDetails() {
    // Reset previous error or customer details
    this.errorMessage = '';
    this.customerDetails = undefined;
 
    if (!this.accountId) {
      this.errorMessage = 'Please enter a valid account number.';
      return;
    }
 
    this.isLoading = true; // Show loading indicator
 
    this.accountService.getCustomerDetailsByAccountId(this.accountId).subscribe({
      next: (data) => {
        this.customerDetails = data; // Store fetched customer details
        this.isLoading = false; // Stop loading
      },
      error: (err) => {
        this.errorMessage = 'Customer not found or invalid account number.'; // Display error message
        this.isLoading = false; // Stop loading
      }
    });
  }
}

