import { Component, OnInit } from '@angular/core';
import { Account } from 'src/app/models/account.model';
import { Transaction } from 'src/app/models/transaction.model';
import { AccountService } from 'src/app/services/account.service';
import { TransactionService } from 'src/app/services/transaction.service';

@Component({
  selector: 'app-transaction-statement',
  templateUrl: './transaction-statement.component.html',
  styleUrls: ['./transaction-statement.component.css']
})
export class TransactionStatementComponent implements OnInit{
  accountNo!:number; 
  fromDate: string = '';            // User input for the from date
  toDate: string = '';              // User input for the to date
  isLoading: boolean = false;       // Loading state
  errorMessage: string = '';        // Error message if any issue occurs
  transactions: Transaction[] = [];
  accounts: Account[] = [];

  noTransactionMessage: string = '';
  accountCreationDate: string = '';

  constructor(private transactionService: TransactionService,private accountService:AccountService) {}

  role: string|null = null;
  customerId: number | null = null;

  ngOnInit(): void {
    const customerData = localStorage.getItem('customer');
    if (customerData) {
      const customer = JSON.parse(customerData);
      this.role = customer.login?.role || null;
      this.customerId = customer.customerId;

      if (this.role === 'USER' && this.customerId) {
        this.accountService.getAccountsByCustomerId(this.customerId).subscribe(accounts => {
          this.accounts = accounts;
        });
      } else 
      if (this.role === 'ADMIN') {
        this.accountService.getAllAccounts().subscribe(accounts => {
          this.accounts = accounts;
        });
      }
    }
  }

  
    onAccountChange() {
      const selectedAcc = this.accounts.find(acc => acc.accountNo === this.accountNo);
      if (selectedAcc) {
        this.accountCreationDate = selectedAcc.createdAt; // Ensure your `Account` model has `creationDate` property
      }
    }
    
    
   fetchTransactions() {
    this.noTransactionMessage = '';  // reset message each time
  
    const today = new Date().toISOString().split('T')[0];
  
    if (this.fromDate < this.accountCreationDate) {
      this.noTransactionMessage = 'Start date cannot be before account creation date.';
      this.transactions = [];
      return;  // stop here if invalid
    }
  
    if (this.toDate > today) {
      this.noTransactionMessage = 'End date cannot be in the future.';
      this.transactions = [];
      return;  
    }
  
    this.transactionService.getTransactionsBetweenDates(this.accountNo, this.fromDate, this.toDate).subscribe({
      next: (data: Transaction[]) => {
        this.transactions = data;
        if (data.length === 0) {
          this.noTransactionMessage = 'No transactions found in the selected date range.';
        }
      },
      error: (err) => {
        this.transactions = [];
        this.noTransactionMessage = err.message || 'Something went wrong.';
      }
    });
  }
}

