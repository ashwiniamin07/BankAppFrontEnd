import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AccountService } from 'src/app/services/account.service';
import { Account } from 'src/app/models/account.model';
import { Router, ActivatedRoute } from '@angular/router';
 
@Component({
  selector: 'app-account-update',
  templateUrl: './account-update.component.html',
  styleUrls: ['./account-update.component.css']
})
export class AccountUpdateComponent implements OnInit {
  accountForm: FormGroup;
  accountNo: number = 0;  // Store the entered account number
  accountTypes = [
    { value: 'Saving', display: 'Savings Account' },
    { value: 'Current', display: 'Current Account' },
    // { value: 'Salary', display: 'Salary Account' },
    // { value: 'FD', display: 'Fixed Deposit (FD) Account' },
    // { value: 'RD', display: 'Recurring Deposit (RD) Account' },
    // { value: 'NRI', display: 'NRI Account' }
  ];
 
  statusMessage: string = '';  // To store success or error message
  statusClass: string = '';  // To set a CSS class for styling success or error message
 
  constructor(
    private fb: FormBuilder,
    private accountService: AccountService,
    private router: Router,
    private route: ActivatedRoute  // To get params from the URL
  ) {
    this.accountForm = this.fb.group({
      accountNo: ['', Validators.required],  // Account No field
      accountType: ['', Validators.required],  // Account Type dropdown
      balance: ['', [Validators.required, Validators.min(1)]], // Balance should be positive
      customerId: ['', [Validators.required, Validators.pattern('^[0-9]*$')]]  // Ensure customerId is numeric
    });
  }
 
  ngOnInit(): void {}
 
  // Fetch the account details based on the accountNo entered by the user
  fetchAccountDetails(): void {
    this.accountNo = this.accountForm.value.accountNo;
 
    if (this.accountNo && this.accountNo > 0) {
      this.accountService.getAccountById(this.accountNo).subscribe(
        (account: Account) => {
          // Populate the form with the account details
          this.accountForm.patchValue({
            accountType: account.accountType,
            balance: account.balance,
            customerId: account.customerId  // Use customerId directly
          });
        },
        (error) => {
          console.error('Error fetching account details:', error);
          alert('Account not found');
        }
      );
    }
  }
 
  // Handle form submission for updating the account
  onSubmit(): void {
    if (this.accountForm.valid) {
      const updatedAccount = this.accountForm.value;
 
      this.accountService.updateAccount(this.accountNo, updatedAccount).subscribe(
        (response) => {
          console.log('Account updated successfully:', response);
 
          // Show success message
          this.statusMessage = 'Account updated successfully!';
          this.statusClass = 'success-message'; // Set success class for styling
 
          // Optionally reset the form after success
          this.accountForm.reset();
        },
        (error) => {
          console.error('Error updating account:', error);
 
          // Show error message
          this.statusMessage = 'Error updating account. Please try again.';
          this.statusClass = 'error-message'; // Set error class for styling
        }
      );
    } else {
      // Show validation error message if form is invalid
      this.statusMessage = 'Please ensure all fields are filled correctly.';
      this.statusClass = 'error-message';
    }
  }
}
 