import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Account } from 'src/app/models/account.model';
import { AccountService } from 'src/app/services/account.service';
import { TransactionService } from 'src/app/services/transaction.service';

@Component({
  selector: 'app-deposit',
  templateUrl: './deposit.component.html',
  styleUrls: ['./deposit.component.css']
})
export class DepositComponent implements OnInit{
  accountId!:number;
  amount!:number;

  accounts: Account[] = [];

  successMessage: string = '';
  errorMessage:string = '';
  
  constructor(
    private transactionService: TransactionService,
    private router:Router, 
    private accountService: AccountService
  ){}

  role: string|null = null;
  customerId: number | null = null;

  ngOnInit(): void {
    const customerData = localStorage.getItem('customer');
    if (customerData) {
      const customer = JSON.parse(customerData);
      this.role = customer.login?.role || null;
      this.customerId = customer.customerId;

      if (this.role === 'USER' && this.customerId) {
        this.accountService.getAccountsByCustomerId(this.customerId).subscribe(accounts => {
          this.accounts = accounts;
        });
      } else 
      if (this.role === 'ADMIN') {
        this.accountService.getAllAccounts().subscribe(accounts => {
          this.accounts = accounts;
        });
      }
    }

    window.addEventListener('storage', (event) => {
      if (event.key === 'customer' && event.newValue === null) {
        window.location.href = '/home';
      }
    });
    console.log('CustomerID:',this.customerId);
    console.log('Role',this.role)
  }
  
  deposit() {
    this.successMessage = '';
    this.errorMessage = '';
  
    if (this.amount <= 0) {
      this.errorMessage = 'Amount must be a positive number.';
      return;
    }
  
    this.transactionService.deposit(this.accountId, this.amount).subscribe({
      next: (response) => {
        this.successMessage = response;
      },
      error: (err) => {
        this.errorMessage = err.error?.message || 'Something went wrong.';
      }
    });
  }

  logout(){
    localStorage.clear();
    sessionStorage.clear();

    this.router.navigate(['/login']);
  }
}
