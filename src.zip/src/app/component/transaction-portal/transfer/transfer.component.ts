import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Account } from 'src/app/models/account.model';
import { AccountService } from 'src/app/services/account.service';
import { TransactionService } from 'src/app/services/transaction.service';

@Component({
  selector: 'app-transfer',
  templateUrl: './transfer.component.html',
  styleUrls: ['./transfer.component.css']
})
export class TransferComponent {
  accountId!:number;
  targetAccountId!:number;
  amount!:number;

  successMessage: string = '';
  errorMessage:string = '';

    accounts: Account[] = [];

    constructor(
        private transactionService: TransactionService,
        private router:Router, 
        private accountService: AccountService
      ){}
    
      role: string|null = null;
      customerId: number | null = null;
    
      ngOnInit(): void {
        const customerData = localStorage.getItem('customer');
        if (customerData) {
          const customer = JSON.parse(customerData);
          this.role = customer.login?.role || null;
          this.customerId = customer.customerId;
    
          if (this.role === 'USER' && this.customerId) {
            this.accountService.getAccountsByCustomerId(this.customerId).subscribe(accounts => {
              this.accounts = accounts;
            });
          } else 
          if (this.role === 'ADMIN') {
            this.accountService.getAllAccounts().subscribe(accounts => {
              this.accounts = accounts;
            });
          }
        }
    
        window.addEventListener('storage', (event) => {
          if (event.key === 'customer' && event.newValue === null) {
            window.location.href = '/home';
          }
        });
        console.log('CustomerID:',this.customerId);
        console.log('Role',this.role)
      }
          
    transfer(){
      this.successMessage = '';
      this.errorMessage = '';

      if (this.amount <= 0) {
        this.errorMessage = 'Amount must be a positive number.';
        return;
      }
    
      this.transactionService.transfer(this.accountId,this.targetAccountId,this.amount).subscribe({
        next: (response) => {
          this.successMessage = response;
        },
        error: (err) => {
          this.errorMessage = err.error?.message || 'Account Not Found.';
        }
      });
    }
  
    logout(){
      localStorage.clear();
      sessionStorage.clear();
  
      this.router.navigate(['/login']);
    }
    

}
