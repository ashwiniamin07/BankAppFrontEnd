import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Account } from 'src/app/models/account.model';
import { Transaction } from 'src/app/models/transaction.model';
import { AccountService } from 'src/app/services/account.service';
import { CustomerServiceService } from 'src/app/services/customer-service.service';
import { TransactionService } from 'src/app/services/transaction.service';

@Component({
  selector: 'app-transaction-portal',
  templateUrl: './transaction-portal.component.html',
  styleUrls: ['./transaction-portal.component.css']
})
export class TransactionPortalComponent implements OnInit {
  showListTransactionForm = false;
  showListTransactionBetweenDatesForm = false;
  accountId!:number;
  targetAccountId!:number;
  amount!:number;
  startDate!:string;
  endDate!:string

  transactions: Transaction[] = [];
  accounts: Account[] = [];

  noTransactionMessage: string = '';
  accountCreationDate: string = '';
  


  constructor(
    private transactionService: TransactionService, 
    private accountService:AccountService, 
    private router:Router, 
    private customerService: CustomerServiceService){}

  role: string|null = null;
  customerId: number | null = null;

  ngOnInit(): void {
    const customerData = localStorage.getItem('customer');
    if (customerData) {
      const customer = JSON.parse(customerData);
      this.role = customer.login?.role || null;
      this.customerId = customer.customerId;

      if (this.role === 'USER' && this.customerId) {
        this.accountService.getAccountsByCustomerId(this.customerId).subscribe(accounts => {
          this.accounts = accounts;
        });
      } else 
      if (this.role === 'ADMIN') {
        this.accountService.getAllAccounts().subscribe(accounts => {
          this.accounts = accounts;
        });
      }
    }

    window.addEventListener('storage', (event) => {
      if (event.key === 'customer' && event.newValue === null) {
        window.location.href = '/home';
      }
    });
    console.log('CustomerID:',this.customerId);
    console.log('Role',this.role)
  }
        
  toggleForm(type:string){
    this.transactions=[];
    this.noTransactionMessage='';
    this.startDate='';
    this.endDate='';
    this.accountId=0;
    this.showListTransactionForm = type == 'listAllTransactions'
    this.showListTransactionBetweenDatesForm = type == 'listTransactionsByDate'
  }


  listAllTransactions(){
    this.transactionService.getAllTransactions(this.accountId).subscribe({
      next: (data: Transaction[]) => {
        this.transactions = data;
        if (data.length === 0) {
          this.noTransactionMessage = 'No transactions found.';
        }
      },
      error: (err) =>{
        this.transactions = [];
        alert(err.message);
      }
    });
  }

  onAccountChange() {
    const selectedAcc = this.accounts.find(acc => acc.accountNo === this.accountId);
    if (selectedAcc) {
      this.accountCreationDate = selectedAcc.createdAt; // Ensure your `Account` model has `creationDate` property
    }
  }
  
  
 listTransactionsByDate() {
  this.noTransactionMessage = '';  // reset message each time

  const today = new Date().toISOString().split('T')[0];

  if (this.startDate < this.accountCreationDate) {
    this.noTransactionMessage = 'Start date cannot be before account creation date.';
    this.transactions = [];
    return;  // stop here if invalid
  }

  if (this.endDate > today) {
    this.noTransactionMessage = 'End date cannot be in the future.';
    this.transactions = [];
    return;  
  }

  this.transactionService.getTransactionsBetweenDates(this.accountId, this.startDate, this.endDate).subscribe({
    next: (data: Transaction[]) => {
      this.transactions = data;
      if (data.length === 0) {
        this.noTransactionMessage = 'No transactions found in the selected date range.';
      }
    },
    error: (err) => {
      this.transactions = [];
      this.noTransactionMessage = err.message || 'Something went wrong.';
    }
  });
}

  logout(){
    localStorage.clear();
    sessionStorage.clear();
    this.router.navigate(['/login']);
  }
  
}
