import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TransactionPortalComponent } from './transaction-portal.component';

describe('TransactionPortalComponent', () => {
  let component: TransactionPortalComponent;
  let fixture: ComponentFixture<TransactionPortalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TransactionPortalComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TransactionPortalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
