

import { Component, OnInit } from '@angular/core';
import { CustomerServiceService } from 'src/app/services/customer-service.service';
import { Router } from '@angular/router';
import { Customer } from 'src/app/interface.models/customer';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  isLoggedIn: boolean = false;

  constructor(
    private customerService: CustomerServiceService, 
    private router: Router
  ) {}

  ngOnInit(): void {
    // Subscribe to the customer observable to monitor login state
    this.customerService.getCustomer().subscribe((customer) => {
      if (customer) {
        this.isLoggedIn = true;  // If customer is logged in, set the flag
      } else {
        this.isLoggedIn = false;  // If customer is not logged in, set the flag
      }
    });
  }

  logout(): void {
    this.customerService.logout(); // Logout user
    this.router.navigate(['/login']); // Navigate to login page
  }
}
