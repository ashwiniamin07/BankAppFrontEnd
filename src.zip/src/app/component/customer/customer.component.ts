import { Component, OnInit } from '@angular/core';
import { Customer } from 'src/app/interface.models/customer';
import { CustomerServiceService } from 'src/app/services/customer-service.service';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {
  selectedPage: string = '';
  role: string = '';
  user: Customer | null = null;
  isLoggedIn: boolean = false;

  constructor(private customerService: CustomerServiceService) {}

  ngOnInit(): void {
    this.customerService.getCustomer().subscribe(customer => {
      this.user = customer;
      this.isLoggedIn = !!customer;

      if (this.isLoggedIn) {
        this.role = customer?.login?.role || '';
        if (this.role === 'USER') {
          this.selectedPage = 'update';
        }
      }
    });
  }

  setSelectedPage(page: string): void {
    if (this.role === 'USER' && page !== 'update') {
      return;
    }
    this.selectedPage = page;
  }
}
