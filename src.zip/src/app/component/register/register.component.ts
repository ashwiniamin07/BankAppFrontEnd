
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormArray, AbstractControl, ValidationErrors } from '@angular/forms';
import { CustomerServiceService } from '../../services/customer-service.service';
import { RegisterDto } from '../../interface.models/registerDto';
import { RegRespDto } from '../../interface.models/regRespDto';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html'
})
export class RegisterComponent {
  registerForm: FormGroup;
  successMessage: string = '';
  errorMessage: string = '';
  fieldErrors: any;

  constructor(private fb: FormBuilder, private customerService: CustomerServiceService) {
    this.registerForm = this.fb.group({
      customer: this.fb.group({
        fullName: ['', [Validators.required, Validators.minLength(2)]],
        contactNo: ['', [Validators.required, Validators.pattern('^[6-9]\\d{9}$')]],
        dob: ['', Validators.required],
      }),
      login: this.fb.group({
        email: ['', [Validators.required, Validators.email]],
        password: ['', [Validators.required, Validators.minLength(8)]],
        role: ['', Validators.required],
      }),
      addressList: this.fb.array([this.createAddressGroup()])
    });
  }

  get addressList(): FormArray {
    return this.registerForm.get('addressList') as FormArray;
  }

  createAddressGroup(): FormGroup {
    return this.fb.group({
      dNo: ['', Validators.required],
      streetName: ['', Validators.required],
      city: ['', Validators.required],
      state: ['', Validators.required],
      pincode: ['', [Validators.required, Validators.min(100000), Validators.max(999999)]],
    });
  }

  addAddress(): void {
    this.addressList.push(this.createAddressGroup());
  }

  onSubmit(): void {
    if (this.registerForm.invalid) {
      this.errorMessage = 'Please fill out all required fields correctly.';
      return;
    }
    const dob = this.registerForm.get('customer.dob')?.value;
    if (dob) {
      const today = new Date();
      const dobDate = new Date(dob);
      if (dobDate > today) {
        this.errorMessage = 'Date of birth must be a past date.';
        return;
      }
    }

    const registerDto: RegisterDto = this.registerForm.value;
    console.log('Form Data:', registerDto);  // Log the form data for debugging

    this.customerService.regCustomer(registerDto).subscribe({
      next: (response: RegRespDto) => {
        this.successMessage = response.message;
        this.errorMessage = '';
        this.registerForm.reset();
      },
      error: (err) => {
        console.log('Error response:', err);  // Log the error for debugging
        if (err.status === 400 && err.error && err.error.includes('Customer already exists')) {
          this.errorMessage = 'Customer with this email already exists. Please try with a different email id.';
        } else {
          this.errorMessage = 'Registration failed. Please try again.';
        }
        this.successMessage = '';
      }
    });

  }
  


}

