import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, BehaviorSubject, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { RegisterDto } from '../interface.models/registerDto';
import { RegRespDto } from '../interface.models/regRespDto';
import { LoginDto } from '../interface.models/loginDto';
import { Customer } from '../interface.models/customer';
import { Address } from '../interface.models/address';
import { Custdto } from '../interface.models/custdto';

@Injectable({
  providedIn: 'root'
})
export class CustomerServiceService {
  private regUrl = 'http://localhost:8083/auth/customer/register'; 
  private apiUrl = 'http://localhost:8083/auth/login';  
  private baseUrl = 'http://localhost:8083/auth/customer'; 

  private customerSubject: BehaviorSubject<Customer | null> = new BehaviorSubject<Customer | null>(null);

  constructor(private http: HttpClient) {
    const storedCustomer = localStorage.getItem('customer');
    if (storedCustomer) {
      this.customerSubject.next(JSON.parse(storedCustomer));
    }
  }

  // Register customer
  regCustomer(registerData: RegisterDto): Observable<RegRespDto> {
    return this.http.post<RegRespDto>(this.regUrl, registerData).pipe(
      catchError(error => {
        console.error('Registration error:', error);
        return throwError(error);  // Propagate error to the component
      })
    );
  }

  // Login customer
  loginCustomer(loginData: LoginDto): Observable<Customer> {
    return this.http.post<Customer>(this.apiUrl, loginData).pipe(
      catchError(error => {
        console.error('Login error:', error);
        return throwError(error);  // Propagate error to the component
      })
    );
  }

  // Get customer role 
  getCustomerRole(): string | null {
    const customer = this.customerSubject.value;
    return customer && customer.login ? customer.login.role : null;  // Return role from Login object
  }

  addCustomer(customer: Customer): Observable<Customer> {
    return this.http.post<Customer>(`${this.baseUrl}/add`, customer).pipe(
      catchError(error => {
        console.error('Add customer error:', error);
        return throwError(error);  // Propagate error to the component
  })
);
  }



  // Set customer after login (to save in localStorage and notify subscribers)
  setCustomer(customer: Customer) {
    localStorage.setItem('customer', JSON.stringify(customer));
    this.customerSubject.next(customer);
  }

  // Get current customer observable
  getCustomer(): Observable<Customer | null> {
    return this.customerSubject.asObservable();
  }

  // Logout customer
  logout() {
    localStorage.removeItem('customer');
    this.customerSubject.next(null); 
  }

  getAllCustomers(): Observable<Customer[]> {
    return this.http.get<Customer[]>(`${this.baseUrl}/get/customers`);
  }

  // Get customer by ID
  getCustomerById(id: number): Observable<Customer> {
    return this.http.get<Customer>(`${this.baseUrl}/getcustomer/${id}`);
  }
  

  // Update customer
  updateCustomer(id: number, customer: Customer): Observable<Customer> {
    return this.http.put<Customer>(`${this.baseUrl}/customer/update/${id}`, customer);
  }
  

  // Delete customer
  deleteCustomer(id: number): Observable<Customer> {
    return this.http.delete<Customer>(`${this.baseUrl}/customer/delete/${id}`);
  }
  // Update customer name
  updateCustomerName(id: number, newName: string): Observable<Customer> {
    const url = `${this.baseUrl}/customer/update-name/${id}`;
    return this.http.patch<Customer>(url, { fullName: newName });
  }

  // Update customer address
  updateCustomerAddress(id: number, address: Address): Observable<Customer> {
    return this.http.patch<Customer>(`${this.baseUrl}/customer/update-address/${id}`, address);
  }

  //update customer DOB
  updateCustomerDob(id: number, dob: string): Observable<Customer> {
    return this.http.patch<Customer>(`${this.baseUrl}/customer/update-dob/${id}`, { dob });
  }

  // Get customer by name
  getCustomersByName(name: string): Observable<Customer[]> {
    return this.http.get<Customer[]>(`${this.baseUrl}/getcustomers/name/${name}`);
  }
  
  //get customer by dob
  getCustomersByDob(dob: string): Observable<Customer[]> {
    return this.http.get<Customer[]>(`${this.baseUrl}/getcustomers/dob/${dob}`);
  }
  
  // Get customer by email
  getCustomerByEmail(email: string): Observable<Customer> {
    return this.http.get<Customer>(`${this.baseUrl}/customer/by-email/${email}`);
  }

  // Get customer by dto
  getCustomerDtoById(id: number): Observable<Custdto> {
    return this.http.get<Custdto>(`${this.baseUrl}/customerdto/${id}`);
  }

  //Update customer dto
  updateCustomerDto(id: number, custDto: Custdto): Observable<Custdto> {
    return this.http.put<Custdto>(`${this.baseUrl}/customer/update-dto/${id}`, custDto);
  }


  
}
