import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Account } from '../models/account.model';
import { Customer } from '../models/customer.model';


@Injectable({
  providedIn: 'root'
})
export class AccountService {
  private baseUrl = `http://localhost:8083/accounts`; 

  constructor(private http: HttpClient) { }

  getAllAccounts(): Observable<Account[]> {
    return this.http.get<Account[]>(`${this.baseUrl}/getall`);
  }

  getAccountById(id: number): Observable<Account> {
    return this.http.get<Account>(`${this.baseUrl}/${id}`);
  }

  

  createAccount(account: Account): Observable<Account> {
    return this.http.post<Account>(`${this.baseUrl}/create`, account);
  }

  updateAccount(accountNo: number, updatedAccount: Account): Observable<Account> {
    return this.http.put<Account>(`${this.baseUrl}/update/${accountNo}`, updatedAccount);
  }
  
  
  deleteAccount(id: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/delete/${id}`);
  }
  freezeAccount(id: number): Observable<string> {
    return this.http.put<string>(`${this.baseUrl}/${id}/freeze`, {},{ responseType: 'text' as 'json' });
  }
  
  unfreezeAccount(id: number): Observable<string> {
    return this.http.put<string>(`${this.baseUrl}/${id}/unfreeze`, {},{ responseType: 'text' as 'json' });
  }
  

  getBalance(id: number): Observable<number> {
    return this.http.get<number>(`${this.baseUrl}/${id}/balance`);
  }

  verifyAccountExists(accountId: number): Observable<boolean> {
    return this.http.get<boolean>(`${this.baseUrl}/${accountId}/exists`);
  }

  getAccountsByCustomerId(customerId: number): Observable<Account[]> {
    return this.http.get<Account[]>(`${this.baseUrl}/customer/${customerId}`);
  }

  getCustomerDetailsByAccountId(accountId: number): Observable<Customer> {
    return this.http.get<Customer>(`${this.baseUrl}/${accountId}/holder`);
  }
 
  getStatement(id: number, from: string, to: string): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}/${id}/statement/${from}/${to}`);
  }

 

}
