import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, catchError, Observable, throwError } from 'rxjs';
import { Transaction } from '../models/transaction.model';
import { Account } from '../models/account.model';
import { Customer } from '../models/customer.model';

@Injectable({
  providedIn: 'root'
})
export class TransactionService {
  private baseUrl = 'http://localhost:8083/accounts';

  private customerSubject: BehaviorSubject<Customer | null> = new BehaviorSubject<Customer | null>(null);

  constructor(private http: HttpClient) { 
    const storedCustomer = localStorage.getItem('customer');
    if (storedCustomer) {
      this.customerSubject.next(JSON.parse(storedCustomer));
    }
  }

  deposit(accountId: number, amount: number): Observable<any>{
    return this.http.post(`http://localhost:8083/accounts/${accountId}/deposit`,amount,{headers: {'Content-Type':'application/json'}, responseType:'text'}).pipe(
      catchError((error:HttpErrorResponse) => {
        const errorMsg = error.error || "Unknown error occured";
        return throwError(() => new Error(errorMsg));
      })
    );
  }

  withdraw(accountId: number, amount: number): Observable<any>{
    return this.http.post(`http://localhost:8083/accounts/${accountId}/withdraw`,amount,{headers: {'Content-Type':'application/json'}, responseType:'text'}).pipe(
      catchError((error:HttpErrorResponse) => {
        const errorMsg = error.error || "Unknown error occured";
        return throwError(() => new Error(errorMsg));
      })
    );
  }

  transfer(accountId: number, targetAccountId: number, amount: number): Observable<any>{
    return this.http.post(`http://localhost:8083/accounts/${accountId}/transfer/${targetAccountId}`,amount,{headers:{'Content-Type':'application/json'}, responseType:'text'}).pipe(
      catchError((error:HttpErrorResponse) => {
        const errorMsg = error.error || "Unknown error occured";
        return throwError(() => new Error(errorMsg));
      })
    );
  }

  getAllTransactions(accountId: number): Observable<Transaction[]>{
    return this.http.get<Transaction[]>(`http://localhost:8083/accounts/${accountId}/transactions`).pipe(
      catchError((error:HttpErrorResponse) => {
        const errorMsg = error.error || "Unknown error occured";
        return throwError(() => new Error(errorMsg));
      })
    );
  }

  getTransactionsBetweenDates(accountId:number, startDate:string, endDate:string): Observable<Transaction[]>{
    return this.http.get<Transaction[]>(`http://localhost:8083/accounts/${accountId}/transactions/${startDate}/${endDate}`).pipe(
      catchError((error:HttpErrorResponse) => {
        const errorMsg = error.error || "Unknown error occured";
        return throwError(() => new Error(errorMsg));
      })
    );
  }

  getAllAccounts(): Observable<Account[]> {
    return this.http.get<Account[]>(`${this.baseUrl}/getall`);
  }

  getAccountsByCustomerId(customerId: number): Observable<Account[]> {
    return this.http.get<Account[]>(`${this.baseUrl}/customer/${customerId}`);
  }

}
