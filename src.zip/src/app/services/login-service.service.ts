import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { LoginDto } from '../interface.models/loginDto';  // Ensure LoginDto is defined

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  private apiUrl = 'http://localhost:8083/auth/login';  // Your backend login URL

  constructor(private http: HttpClient) { }

  // Method to send login request to the backend
  login(loginDto: LoginDto): Observable<any> {
    return this.http.post(this.apiUrl, loginDto); // Send POST request with login data
  }
}

