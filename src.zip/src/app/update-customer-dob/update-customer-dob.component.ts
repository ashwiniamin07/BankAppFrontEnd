import { Component } from '@angular/core';
import { CustomerServiceService } from '../services/customer-service.service';
import { Customer } from '../interface.models/customer';

@Component({
  selector: 'app-update-customer-dob',
  templateUrl: './update-customer-dob.component.html',
  styleUrls: ['./update-customer-dob.component.css']
})
export class UpdateCustomerDobComponent {
  customerId!: number;
  dob: string = '';
  successMessage = '';
  errorMessage = '';
  dobLoaded = false;

  constructor(private customerService: CustomerServiceService) {}

  fetchDob(): void {
    if (!this.customerId || this.customerId <= 0) {
      this.errorMessage = 'Enter a valid customer ID';
      return;
    }

    this.customerService.getCustomerById(this.customerId).subscribe(
      (customer: Customer) => {
        this.dob = customer.dob || '';
        this.dobLoaded = true;
        this.errorMessage = '';
        this.successMessage = '';
      },
      (error) => {
        this.errorMessage = error.error.message || 'Customer not found';
        this.dobLoaded = false;
      }
    );
  }

  updateDob(): void {
    if (!this.dobLoaded) {
      this.errorMessage = 'Fetch DOB first';
      return;
    }

    if (!this.dob) {
      this.errorMessage = 'DOB cannot be empty';
      return;
    }

    this.customerService.updateCustomerDob(this.customerId, this.dob).subscribe(
      (updated: Customer) => {
        this.successMessage = 'DOB updated successfully';
        this.errorMessage = '';
      },
      (error) => {
        this.errorMessage = error.error.message || 'Failed to update DOB';
        this.successMessage = '';
      }
    );
  }
}
