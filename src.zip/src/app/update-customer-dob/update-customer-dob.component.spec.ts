import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateCustomerDobComponent } from './update-customer-dob.component';

describe('UpdateCustomerDobComponent', () => {
  let component: UpdateCustomerDobComponent;
  let fixture: ComponentFixture<UpdateCustomerDobComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdateCustomerDobComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UpdateCustomerDobComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
