export interface Transaction{
    transactionId : number,
    accountNo : number,
    senderAccountNo : number,
    receiverAccountNo : number,
    amount : number,
    transactionType : string,
    timeStamp : string,
    status : string
    customerId:number;
}