export interface Account {
    accountNo: number;
    accountType: string;
    balance: number;
    createdAt: string;
    isFrozen: boolean;
    customerId: number;  
  }
  