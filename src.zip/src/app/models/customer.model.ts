export interface Login {
    email: string;
  }
  
  export interface Customer {
    customerId: number;
    fullName: string;
    contactNo: string;
    dob: string;
    login: Login;
    email: string;
  
  }
  