import { Component, OnInit } from '@angular/core';
import { CustomerServiceService } from '../services/customer-service.service';
import { Customer } from '../interface.models/customer';
import { Address } from '../interface.models/address';

@Component({
  selector: 'app-update-customer',
  templateUrl: './update-customer.component.html',
  styleUrls: ['./update-customer.component.css']
})
export class UpdateCustomerComponent implements OnInit {
  customer: Customer = {
    customerId: 0,
    fullName: '',
    contactNo: '',
    dob: '',
    login: { email: '', password: '', role: '' },
    address: [{ dNo: '', streetName: '', city: '', state: '', pincode: 0 }]
  };
  role: string | null = null;
  loggedInCustomerId: number | null = null;
  searchId: number = 0;
  error: string = '';
  successMessage: string = '';

  constructor(private customerService: CustomerServiceService) {}

  ngOnInit(): void {
    this.customerService.getCustomer().subscribe((cust) => {
      if (cust) {
        this.role = cust.login?.role ?? null;

        this.loggedInCustomerId = cust.customerId;

        if (this.role === 'USER') {
          // Auto-fetch user's own data
          this.fetchCustomerById(cust.customerId);
        }
      }
    });
  }

  // Admin initiates customer fetch
  fetchCustomerByAdmin(): void {
    if (!this.searchId) {
      this.error = 'Please enter a valid Customer ID';
      return;
    }

    this.fetchCustomerById(this.searchId);
  }

  // Shared method to fetch customer by ID
  fetchCustomerById(id: number): void {
    this.customerService.getCustomerById(id).subscribe(
      (data) => {
        this.customer = {
          ...data,
          login: data.login ?? { email: '', password: '', role: '' },
          address: data.address ?? [{ dNo: '', streetName: '', city: '', state: '', pincode: 0 }]
        };
        this.error = '';
        this.successMessage = 'Customer details loaded successfully.';
        setTimeout(() => (this.successMessage = ''), 3000);
      },
      (error) => {
        this.error = 'Customer not found';
        this.successMessage = '';
      }
    );
  }

  updateCustomer(): void {
    const idToUpdate = this.customer.customerId;

    this.customerService.updateCustomer(idToUpdate, this.customer).subscribe(
      () => {
        this.successMessage = 'Customer updated successfully';
        this.error = '';
        setTimeout(() => (this.successMessage = ''), 3000);
      },
      (error) => {
        this.error = 'Error updating customer';
        this.successMessage = '';
      }
    );
  }
}
