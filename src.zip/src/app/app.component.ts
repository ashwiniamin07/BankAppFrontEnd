import { Component, OnInit } from '@angular/core';
import { Customer } from 'src/app/interface.models/customer';
import { CustomerServiceService } from 'src/app/services/customer-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'bankapp';
  isLoggedIn: boolean = false;
    user: Customer | null = null;
  
    constructor(private customerService: CustomerServiceService, private router: Router) {}
  
    ngOnInit(): void {
      // Get the customer data and update the login state
      this.customerService.getCustomer().subscribe((customer) => {
        if (customer) {
          this.isLoggedIn = true;
          this.user = customer;
        } else {
          this.isLoggedIn = false;
          this.user = null;
        }
      });
    }
  
    logout() {
      this.customerService.logout(); // Logout the user
      this.router.navigate(['/login']); // Redirect to login page
    }
  
    viewProfile() {
      // You can either navigate to a profile page or show a modal with user details
      // Example of navigation to a profile page:
      this.router.navigate(['/profile']); // Assuming there's a profile page
    }
  
}
